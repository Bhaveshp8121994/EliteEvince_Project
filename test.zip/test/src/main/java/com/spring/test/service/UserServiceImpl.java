package com.spring.test.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.test.model.User;
import com.spring.test.repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl  implements UserService{

	@Autowired
	UserRepository userRepository;


	@Override
	public List<User> getUserList() {
		
		return userRepository.findAllByIsActiveTrue();
	}


	@Override
	public void saveOrUpdate(User user) {
		
		userRepository.save(user);
	}


	@Override
	public User findById(int id) {
		
		return userRepository.findById(id);
	}


	@Override
	public void delete(User user) {
		
		userRepository.delete(user);
		
	}




}
