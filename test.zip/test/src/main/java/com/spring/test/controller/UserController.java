package com.spring.test.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.spring.test.model.User;
import com.spring.test.service.UserService;

@Controller
public class UserController {

	@Autowired
	UserService userService;

	@GetMapping("/")
	public String getHome(Model model) {

		System.out.println("Hello home");

		return "home";

	}

	
	@GetMapping("/listUser")
	private List<User> getUserList(Model model) {

		List<User> userList = userService.getUserList();
		model.addAttribute("userList", userList);
		System.out.println("user list" + userList);

		return userList;
	}

	@GetMapping("/register")
	public String showRegister(Model model) {

		User user = new User();

		model.addAttribute("user", user);
		return "register";
	}
	
	@PostMapping("/register")
	public String addUser(HttpServletRequest request,User users) {

		Integer userId =  Integer.parseInt(request.getParameter("id"));
		
		if(userId == 0) { 
		
		User user = new User();
	
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String dateOfBirth = request.getParameter("dateOfBirth");
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		user.setFirstname(firstname);
		user.setLastname(lastname);
		user.setDateOfBirth(dateOfBirth);
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setIsActive(true);
		
		userService.saveOrUpdate(user);
		
		} else {
			
		User user = userService.findById(users.getId());
		
		System.out.println("edit user::"+user.toString());
		
		user.setFirstname(users.getFirstname());
		user.setLastname(users.getLastname());
		user.setDateOfBirth(users.getDateOfBirth());
		user.setUsername(users.getUsername());
		user.setPassword(users.getPassword());
		user.setEmail(users.getEmail());

		userService.saveOrUpdate(user);
			
		}
		System.out.println("insert data sucessfully");
		
		return "redirect:/listUser";
	}

	@GetMapping("/editUser/{id}")
	private String getUserById(@PathVariable("id") int id,Model model) {
		
		User user = userService.findById(id);

		model.addAttribute("user", user);
		
		return "register";
	}
	
	
	@GetMapping("/deleteUser/{id}")
 	private String deleteUserById(@PathVariable("id") int id) {

		User user = userService.findById(id);
		
		userService.delete(user);
		
		/* user.setIsActive(false);
		  userService.saveOrUpdate(user);
		 */

		return "redirect:/listUser";
	}

}
