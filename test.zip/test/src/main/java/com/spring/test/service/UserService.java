package com.spring.test.service;

import java.util.List;
import com.spring.test.model.User;


public interface UserService {

	List<User> getUserList();

	void saveOrUpdate(User user);

	User findById(int id);

	void delete(User user);

	
}
